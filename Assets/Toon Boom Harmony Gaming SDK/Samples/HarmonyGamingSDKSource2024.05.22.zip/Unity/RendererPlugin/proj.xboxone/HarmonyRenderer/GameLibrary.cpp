// GameLibrary.cpp : Defines the exported functions for the DLL application.
//

#include "pch.h"

// This export exists only to generate a LIB to be consumed by the primary 
// game executable.

__declspec(dllexport) void Initialize()
{
}