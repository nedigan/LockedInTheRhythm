#include "IO_Buffer.h"
#include "UT_String.h"

#include <stdio.h>
#include <string.h>

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - IO_Buffer::Impl
#endif
class IO_Buffer::Impl
{
	MEM_OVERRIDE

	friend class IO_Buffer;

public:

	Impl(size_t initialSize, size_t extensionBlockSize = 0x200)
		:_totalSize(initialSize), _writtenSize(0), _currentPosition(0), _extensionBlockSize(extensionBlockSize)
	{
		_memory = (char*)MEM_ALLOC(initialSize);
	}

	~Impl()
	{
	}

private:

	const char *_memory;
	size_t _extensionBlockSize;
	size_t _writtenSize;
	size_t _totalSize;
	size_t _currentPosition;
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 0
#pragma mark - IO_File::Impl
#endif

IO_Buffer::IO_Buffer(size_t initialSize, size_t extensionBlockSize)
{
	_i = new Impl(initialSize);
}

IO_Buffer::~IO_Buffer()
{
	delete _i;
}

void IO_Buffer::close(void* &ptr, size_t &size)
{
	ptr = (char*)_i->_memory;
	_i->_memory = NULL;
	size = _i->_writtenSize;
	_i->_writtenSize = 0;
	_i->_totalSize = 0;
	_i->_currentPosition = 0;
}

size_t IO_Buffer::read(void* lpBuf, size_t nCount)
{
	size_t readAvailable = _i->_writtenSize - _i->_currentPosition;
	size_t readAmount = nCount <= readAvailable ? nCount : readAvailable;
	memcpy(lpBuf, &_i->_memory[_i->_currentPosition], readAmount);
	_i->_currentPosition += readAmount;
	return readAmount;
}

void IO_Buffer::write(const void* lpBuf, size_t nCount)
{
	size_t writeAvailable = _i->_totalSize - _i->_currentPosition;
	if (nCount > writeAvailable)
	{
		size_t newSize = _i->_totalSize;
		do
		{
			newSize += _i->_extensionBlockSize;
			writeAvailable = newSize - _i->_currentPosition;
		} while (nCount > writeAvailable);
		char* newPtr = (char*)MEM_REALLOC((void*)_i->_memory, newSize);
		if (newPtr == NULL)
		{
			return;
		}
		_i->_memory = newPtr;
		_i->_totalSize = newSize;
	}

	memcpy((void*)(_i->_memory + _i->_currentPosition), lpBuf, nCount);
	_i->_currentPosition += nCount;
	if (_i->_currentPosition > _i->_writtenSize)
	{
		_i->_writtenSize = _i->_currentPosition;
	}
}

void IO_Buffer::seek(size_t addr)
{
	_i->_currentPosition = addr;
}

size_t IO_Buffer::tell()
{
	return _i->_currentPosition;
}

void IO_Buffer::reset()
{
	_i->_currentPosition = 0;
}

bool IO_Buffer::isEOF()
{
	return _i->_currentPosition == _i->_writtenSize;
}

size_t IO_Buffer::size() const
{
	return _i->_writtenSize;
}

UT_String IO_Buffer::streamName() const
{
	return UT_String("Buffer");
}

