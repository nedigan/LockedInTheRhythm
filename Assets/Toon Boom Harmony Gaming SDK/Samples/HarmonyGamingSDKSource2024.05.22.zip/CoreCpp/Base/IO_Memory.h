#ifndef _IO_MEMORY_H_
#define _IO_MEMORY_H_

#include "IO_Stream.h"
#include "MEM_Override.h"

/*!
 *  @class IO_Memory
 *  Stream onto a byte buffer
 */
class IO_Memory : public IO_Stream
{
	MEM_OVERRIDE

public:
	IO_Memory(const void *memory, size_t size);
	virtual ~IO_Memory();

	// IO_Stream interface
	virtual size_t       read(void* lpBuf, size_t nCount);
	virtual void         write(const void* lpBuf, size_t nCount);
	virtual void         seek(size_t addr);
	virtual size_t       tell();
	virtual void         reset();
	virtual bool	       isEOF();
	virtual size_t       size() const;

	virtual UT_String    streamName() const;

private:

	//  non-implemented constructors.
	IO_Memory(const IO_Memory&);
	IO_Memory &operator= (const IO_Memory&);

private:

	class Impl;
	Impl *_i;
};

#endif // _IO_MEMORY_H_
