/*
 * Copyright Toon Boom Animation Inc.

 * QtScript for Harmony that implements an export to animated sprite sheets.
 *
 * This script relies on these Harmony plugins
 *   QtScriptBindings - plugin for Qt XML generation support.
 *   UtransformBinding - plugin for utransform image processing.
 *   TextureAtlas - plugin that assemble images into a sprite sheet.
 *
 * Entry functions:
 *   TB_ExportToSpriteSheets() - export the current display (including the DisplayAll fake display).
 *
 * Modifications:
 *
 * 2016.03.07 -- Fixed errors in the velocity curves calculations when exporting with scene markers
 * 2016.03.16 -- Fixed errors in the game bone curves calculations when exporting with scene markers
 * 2017.03.05 -- Fixed bones length when they are too short
 * 2017.04.08 -- Added possibility to export skin
 * 2018.03.29 -- Fixed error with incorrect matrix type
 * 2020.05.13 -- Fix export via scene markers after scene markers ugprade
 * 2022.02.01 -- Rewrite to support node baking, faster performance, audio export
 * 2022.10.25 -- Palette variation supports export to multiple sprite sheets, fix for cloned drawing export, various edge case fixes for rewrite
 */

var GameExportWindow = require("./game/TB_GameExportWindow.js");

function TB_ExportToSpriteSheets() {
  GameExportWindow.open();
}