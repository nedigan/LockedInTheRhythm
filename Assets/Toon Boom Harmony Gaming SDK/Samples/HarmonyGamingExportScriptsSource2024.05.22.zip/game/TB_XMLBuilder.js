/*
 * Copyright Toon Boom Animation Inc - 2022
 */

var ObjUtil = require("./TB_ObjUtil.js");
var Iter = require("./TB_Iter.js").Iter;

/**
 * Simplifies process of constructing XML files using a deeply nested blueprint format
 * @typedef {{ tag: string, attributes?: any, children?: Blueprint[] }} Blueprint
 * @param {Blueprint} blueprint
 */
exports.Builder = function (blueprint) {

  /**
   * Build out QDomDocument object using declared blueprint.
   * Unfortunately QDomDocument does not respect the order of attributes when using toString()
   */
  this.toQDomDocument = function () {
    var document = new QDomDocument();
    var element = toQDomDocumentImpl(document, blueprint);
    document.appendChild(element);
    return document;
  }

  /**
   * Build out raw string of XML content.
   * This version respects the order of the attributes as they are declared in the blueprint
   */
  this.toXMLString = function () {
    return toXMLStringImpl(blueprint, 0) + "\r\n";
  }

  /**
   * @param {QDomDocument} document
   * @param {Blueprint} blueprint
   */
  function toQDomDocumentImpl(document, blueprint) {
    var element = document.createElement(blueprint.tag);
    if (blueprint.attributes != null)
    {
      for (var idx in blueprint.attributes)
      {
        var attribute = blueprint.attributes[idx];
        if (attribute == null)
          continue;
        var value = typeof attribute == "number" || typeof attribute == "string"
          ? attribute
          : "" + attribute;
        element.setAttribute(idx, value);
      };
    }
    if (blueprint.children != null)
    {
      for (var idx in blueprint.children)
      {
        var child = blueprint.children[idx];
        var childElement = toQDomDocumentImpl(document, child);
        element.appendChild(childElement);
      };
    }
    return element;
  }

  /**
   * @param {Blueprint} blueprint
   * @param {number} tabDepth
   * @returns {string}
   */
  function toXMLStringImpl(blueprint, tabDepth) {
    var attributesString = blueprint.attributes == null ? null
      : ObjUtil.entries(blueprint.attributes)
        .map(function (attribute) {
          if (attribute.value == null)
            return null;
          return /**@type string*/(attribute.key) + "=\"" + attribute.value + "\"";
        })
        .filter(Iter.notNull)
        .join(" ");
    var childrenString = blueprint.children == null ? null
      : blueprint.children
        .map(function (child) {
          return toXMLStringImpl(child, tabDepth + 1);
        })
        .join("\r\n");
    var tabSection = ""; for (var i = 0; i < tabDepth; i++) tabSection += " ";
    var openingSection = "<" + (attributesString == null ? blueprint.tag
      : blueprint.tag + " " + attributesString);
    var closingSection = childrenString == null ? "/>"
      : ">\r\n" + childrenString + "\r\n" + tabSection + "</" + blueprint.tag + ">";
    return tabSection + openingSection + closingSection;
  }
};

exports.Blueprint = {};

/**
 * @param {string} string
 * @returns {Blueprint}
 */
exports.Blueprint.fromXMLString = function (string) {
  /**
   * @param {QDomElement} element
   * @returns {Blueprint}
   */
  function recursiveParse(element) {
    var attributesContainer = element.attributes();
    var attributes = [];
    for (var i = 0; i < attributesContainer.length(); i++)
    {
      var item = attributesContainer.item(i);
      var stringValue = item.nodeValue();
      attributes.push({
        key: item.nodeName(),
        value: isNaN(/**@type any*/(stringValue))
          ? stringValue
          : parseFloat(stringValue)
      });
    }

    var children = [];
    var child = element.firstChildElement();
    while (child != null && child.nodeName != null && child.nodeName().length > 0)
    {
      children.push(child);
      child = child.nextSiblingElement();
    }

    return {
      tag: element.tagName(),
      attributes: attributes.length == 0 ? undefined : ObjUtil.fromEntries(attributes),
      children: children.length == 0 ? undefined : children.map(recursiveParse)
    };
  }

  var document = new QDomDocument();
  document.setContent(string);
  return recursiveParse(/**@type {QDomElement}*/(document.firstChildElement()));
}