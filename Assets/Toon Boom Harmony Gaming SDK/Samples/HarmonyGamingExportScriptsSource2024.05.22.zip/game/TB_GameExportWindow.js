/*
 * Copyright Toon Boom Animation Inc - 2021
 */

var ProgressBar = require("./TB_ProgressBar.js").ProgressBar;
var GameExport = require("./TB_GameExport.js").GameExport;
var XML = require("./TB_XMLBuilder.js");
var Iter = require("./TB_Iter.js").Iter;
var FileUtil = require("./TB_FileUtil.js");
var ObjUtil = require("./TB_ObjUtil.js");
var ValidationChecks = require("./TB_ValidationChecks.js");

/**
 * @template {Schema} T
 * @param {string} category
 * @param {T} schema
 */
function SettingsCategory(category, schema) {

  /**
   * @param {Record<string, FromSchema<T>>} defaults
   */
  this.load = function (defaults) {
    var subCategoryCount = preferences.getInt(category + "_COUNT", 0);
    var categorySettings = /**@type Record<String, FromSchema<T>>*/({});
    if (subCategoryCount == 0)
    {
      categorySettings = defaults;
    }
    else
    {
      for (var rowIdx = 0; rowIdx < subCategoryCount; rowIdx++)
      {
        var subEntries = ObjUtil.entries(schema).map(function (schemaEntry) {
          var subName = [category, rowIdx, /**@type string*/(schemaEntry.key).toUpperCase()].join("_");
          function getValue() {
            switch (schemaEntry.value)
            {
              case "number":
                return preferences.getInt(subName, 0);
              case "boolean":
                return preferences.getBool(subName, false);
              case "string":
                return preferences.getString(subName, "");
            }
          }
          return { key: schemaEntry.key, value: getValue() };
        });
        categorySettings[
          preferences.getString([category, rowIdx, "NAME"].join("_"), "unnamed")
        ] = /**@type FromSchema<T>*/(ObjUtil.fromEntries(/**@type any*/(subEntries)));
      }
    }
    return categorySettings;
  }
  /**
   * @param {Record<string, FromSchema<T>>} settings
   */
  this.save = function (settings) {
    var resKeys = Object.keys(settings);
    preferences.setInt(category + "_COUNT", resKeys.length);
    ObjUtil.entries(settings).forEach(function (settingsEntry, rowIdx) {
      preferences.setString([category, rowIdx, "NAME"].join("_"), settingsEntry.key);
      ObjUtil.entries(settingsEntry.value).forEach(function (settingEntry) {
        var subName = [category, rowIdx, /**@type string*/(settingEntry.key).toUpperCase()].join("_");
        switch (typeof settingEntry.value)
        {
          case "number":
            return preferences.setInt(subName, settingEntry.value);
          case "boolean":
            return preferences.setBool(subName, settingEntry.value);
          case "string":
            return preferences.setString(subName, settingEntry.value);
        }
      });
    });
  }
}

var spriteResolutionCategory = new SettingsCategory(
  "GAME_ENGINE_SPRITE_RESOLUTION",
  { height: "number", width: "number" });

var palettesCategory = new SettingsCategory(
  "GAME_ENGINE_PALETTES",
  { exclude: "boolean" });


function loadSettings() {
  var loadedSettings = {
    fixResolution: preferences.getBool("GAME_ENGINE_FIX_RESOLUTION", false),
    individualSprites: preferences.getBool("GAME_ENGINE_INDIVIDUAL_SPRITES", false),
    excludeEmptyDrawings: preferences.getBool("GAME_ENGINE_EXCLUDE_EMPTY_DRAWINGS", true),
    precalculateBezier: preferences.getBool("GAME_ENGINE_PRECALCULATE_BEZIER", false),
    encodeToTBG: preferences.getBool("GAME_ENGINE_ENCODE_TBG", false),
    includeOverlayAndUnderlay: preferences.getBool("GAME_ENGINE_INCLUDE_OVERLAY_AND_UNDERLAY", false),
    reuseFrames: preferences.getBool("GAME_ENGINE_REUSE_FRAMES", true),
    reuseFramesThreshold: preferences.getInt("GAME_ENGINE_REUSE_FRAMES_THRESHOLD", 2),
    unitScalePreset: preferences.getString("GAME_ENGINE_UNIT_SCALE_PRESET", "1 pixel : 1 unit"),
    unitScale: preferences.getDouble("GAME_ENGINE_UNIT_SCALE", 1.0),
    maxWidth: preferences.getInt("GAME_ENGINE_RESX", 2048),
    maxHeight: preferences.getInt("GAME_ENGINE_RESY", 2048),
    savingName: preferences.getString("GAME_ENGINE_EXPORT_NAME", scene.currentVersionName()),
    resolutionType: /**@type {"POT" | "NPOT" | "ANY"}*/(preferences.getString("GAME_ENGINE_RESOLUTION_TYPE", "POT")),
    savingPath: preferences.getString("GAME_ENGINE_TO_EXPORT", scene.currentProjectPathRemapped()),
    useSceneMarkers: preferences.getBool("GAME_ENGINE_USE_SCENE_MARKERS", true),
    spriteResolutions: spriteResolutionCategory.load({
      "HD": {
        width: 1280,
        height: 720,
      },
      "FullHD": {
        width: 1920,
        height: 1080,
      },
      "QuadHD": {
        width: 2560,
        height: 1440,
      },
    }),
    exportPalettes: palettesCategory.load({}),
    clearTextureFolder: false,
    overwriteProject: false,
    bakeAllGroups: false,
  };
  return loadedSettings;
}
/**
 * @param {Partial<Settings>} settings
 */
function saveSettings(settings) {
  if (settings.fixResolution != null) preferences.setBool("GAME_ENGINE_FIX_RESOLUTION", settings.fixResolution);
  if (settings.individualSprites != null) preferences.setBool("GAME_ENGINE_INDIVIDUAL_SPRITES", settings.individualSprites);
  if (settings.excludeEmptyDrawings != null) preferences.setBool("GAME_ENGINE_EXCLUDE_EMPTY_DRAWINGS", settings.excludeEmptyDrawings);
  if (settings.precalculateBezier != null) preferences.setBool("GAME_ENGINE_PRECALCULATE_BEZIER", settings.precalculateBezier);
  if (settings.encodeToTBG != null) preferences.setBool("GAME_ENGINE_ENCODE_TBG", settings.encodeToTBG);
  if (settings.includeOverlayAndUnderlay != null) preferences.setBool("GAME_ENGINE_INCLUDE_OVERLAY_AND_UNDERLAY", settings.includeOverlayAndUnderlay);
  if (settings.reuseFrames != null) preferences.setBool("GAME_ENGINE_REUSE_FRAMES", settings.reuseFrames);
  if (settings.reuseFramesThreshold != null) preferences.setInt("GAME_ENGINE_REUSE_FRAMES_THRESHOLD", settings.reuseFramesThreshold);
  if (settings.unitScalePreset != null) preferences.setString("GAME_ENGINE_UNIT_SCALE_PRESET", settings.unitScalePreset);
  if (settings.unitScale != null) preferences.setDouble("GAME_ENGINE_UNIT_SCALE", settings.unitScale);
  if (settings.maxWidth != null) preferences.setInt("GAME_ENGINE_RESX", settings.maxWidth);
  if (settings.maxHeight != null) preferences.setInt("GAME_ENGINE_RESY", settings.maxHeight);
  if (settings.savingName != null) preferences.setString("GAME_ENGINE_EXPORT_NAME", settings.savingName);
  if (settings.resolutionType != null) preferences.setString("GAME_ENGINE_RESOLUTION_TYPE", settings.resolutionType);
  if (settings.savingPath != null) preferences.setString("GAME_ENGINE_TO_EXPORT", settings.savingPath);
  if (settings.useSceneMarkers != null) preferences.setBool("GAME_ENGINE_USE_SCENE_MARKERS", settings.useSceneMarkers);
  if (settings.spriteResolutions != null) spriteResolutionCategory.save(settings.spriteResolutions);
  if (settings.exportPalettes != null) palettesCategory.save(settings.exportPalettes);
}

var Tabs = {
  ProjectSettings: 0,
  SpriteSheet: 1,
  SpriteResolution: 2,
  Palettes: 3,
}

/**@type {Record<string, number | undefined>}*/
var presetUnitScales = {
  "Custom": undefined,
  "1 pixel : 1 unit": scene.currentResolutionY() / scene.numberOfUnitsY(),
  "1 field : 1 unit": 1.0,
  "10 fields : 1 unit": 0.1,
  "100 fields : 1 unit": 0.01,
}

/**
 * @param {Settings} settings
 */
function GameExportUI(settings) {

  var ui = UiLoader.load(specialFolders.resource + "/scripts/TB_ExportToSpriteSheets.ui");

  /**
   * Directory Section
   */
  ui.gbDirectory.savingPath.setText(settings.savingPath);
  ui.gbDirectory.savingName.setText(settings.savingName);
  ui.gbDirectory.btnFile2.clicked.connect(function () {
    var path = FileDialog.getExistingDirectory(settings.savingPath, translator.tr("Select directory to save"));
    if (path != null && path != "")
    {
      ui.gbDirectory.savingPath.setText(path);
    }
  });

  /**
   * Stage Section
   * * TODO this setting conflicts with Skin metadata which always contains scene markers
   */
  ui.gbStage.chkSeparateFiles.setChecked(settings.useSceneMarkers);

  var progressBar = new ProgressBar(false, ui);
  var gameExport = new GameExport(settings, progressBar);
  var newAnimationNames = gameExport.animationNames;
  progressBar.close();

  function updateClips() {
    ui.gbStage.lstStage.clear();
    var stagePath = [ui.gbDirectory.savingPath.text, ui.gbDirectory.savingName.text, "stage.xml"].join("/");
    var stageXML = FileUtil.readString(stagePath, { showError: false });
    if (stageXML != null)
    {
      var existingStages = XML.Blueprint.fromXMLString(stageXML).children;
      if (existingStages != null)
      {
        var override = new QColor(255, 100, 100);
        var overwriteProject = ui.chkOverwriteProject.checked;
        existingStages
          .map(function (stage) { return stage.attributes.name; })
          .forEach(function (clipName) {
            var lineEdit = new QListWidgetItem(clipName);
            if (overwriteProject || newAnimationNames.indexOf(clipName) >= 0)
              lineEdit.setForeground(override);
            ui.gbStage.lstStage.addItem(lineEdit);
          });
      }
    }
  }
  ui.gbDirectory.savingPath.editingFinished.connect(updateClips);
  ui.gbDirectory.savingName.editingFinished.connect(updateClips);
  updateClips();

  /**
   * Project Tab
   */
  var projectTab = ui.tabWidget.widget(Tabs.ProjectSettings);
  projectTab.cbUnitScalePreset.setCurrentIndex(Object.keys(presetUnitScales).indexOf(settings.unitScalePreset));
  projectTab.cbUnitScalePreset["currentIndexChanged(int)"].connect(function (index) {
    var unitScale = presetUnitScales[Object.keys(presetUnitScales)[index]];
    if (unitScale == null)
      return;
    projectTab.sbUnitScale.setValue(unitScale);
  });
  projectTab.sbUnitScale.setValue(presetUnitScales[settings.unitScalePreset] || settings.unitScale);
  projectTab.sbUnitScale["valueChanged(double)"].connect(function (value) {
    var presetIndex = new Iter(Object.keys(presetUnitScales))
      .findIndex(function (key) { return Math.abs((presetUnitScales[key] || 0) - value) < 0.001 })
    if (presetIndex != null)
      return;
    projectTab.cbUnitScalePreset.setCurrentIndex(Object.keys(presetUnitScales).indexOf("Custom"));
  });

  /**
   * Sprite Sheet Tab
   */
  var sheetTab = ui.tabWidget.widget(Tabs.SpriteSheet);
  sheetTab.sbMaxWidth.setValue(settings.maxWidth);
  sheetTab.sbMaxHeight.setValue(settings.maxHeight);
  sheetTab.cbResType.setCurrentIndex(sheetTab.cbResType.findText(settings.resolutionType));
  sheetTab.rbFixed.setChecked(settings.fixResolution);
  sheetTab.rbExpand.setChecked(!settings.fixResolution);
  sheetTab.cbReuseFrames.setChecked(settings.reuseFrames);
  sheetTab.sbThreshold.setValue(settings.reuseFramesThreshold);

  /**
   * Resolutions Tab
   */
  var resTab = ui.tabWidget.widget(Tabs.SpriteResolution);
  var resKeys = Object.keys(settings.spriteResolutions);
  for (var resIdx = 0; resIdx < resKeys.length; resIdx++)
  {
    var resKey = resKeys[resIdx];
    var resolutionSetting = settings.spriteResolutions[resKey];
    resTab.tblResolution.insertRow(resIdx);
    resTab.tblResolution.setItem(resIdx, 0, new QTableWidgetItem(resKey));
    resTab.tblResolution.setItem(resIdx, 1, new QTableWidgetItem(resolutionSetting.width.toString()));
    resTab.tblResolution.setItem(resIdx, 2, new QTableWidgetItem(resolutionSetting.height.toString()));
  }
  resTab.btnAddRes.clicked.connect(function () {
    resTab.tblResolution.insertRow(resTab.tblResolution.rowCount);
  });
  UiLoader.setSvgIcon(resTab.btnAddRes, "colour/addcolour.svg");
  resTab.btnRemRes.clicked.connect(function () {
    resTab.tblResolution.removeRow(resTab.tblResolution.currentRow());
  });
  UiLoader.setSvgIcon(resTab.btnRemRes, "colour/deletecolour.svg");

  /**
   * Palettes Tab
   */
  var paletteTab = ui.tabWidget.widget(Tabs.Palettes);
  gameExport.paletteVariations.forEach(function (paletteVariation) {
    var paletteName = paletteVariation.uiName;
    var paletteSetting = settings.exportPalettes[paletteName];
    var listItem = new QListWidgetItem(paletteName);
    listItem.setCheckState(paletteSetting == null ? Qt.Checked : paletteSetting.exclude ? Qt.Unchecked : Qt.Checked);
    paletteTab.variationList.addItem(listItem);
  });

  /**
   * Extra Settings Section
   */
  ui.chkClearTextureFolder.setChecked(settings.clearTextureFolder);
  ui.chkOverwriteProject.setChecked(settings.overwriteProject);
  ui.chkOverwriteProject.clicked.connect(updateClips);
  ui.chkPreBez.setChecked(settings.precalculateBezier);
  ui.chkIndividualSprites.setChecked(settings.individualSprites);
  ui.chkExcludeEmptyDrawings.setChecked(settings.excludeEmptyDrawings);
  ui.chkTBG.setChecked(settings.encodeToTBG);
  ui.chkIncludeOverUnder.setChecked(settings.includeOverlayAndUnderlay);
  ui.btnCancel.clicked.connect(ui.close);

  /**
   * Locks this thread until user finishes interacting with UI.
   */
  this.exec = function () {
    ui.exec();
    return this;
  }

  /**
   * @return {Settings}
   */
  this.updatedSettings = function () {

    var spriteResolutions = /**@type {Record<String, { width: number, height: number }>}*/({});
    for (var resIdx = 0; resIdx < resTab.tblResolution.rowCount; resIdx++)
    {
      var name = resTab.tblResolution.item(resIdx, 0);
      if (name == null || name.text().length == 0)
        continue;
      var item;
      spriteResolutions[name.text()] = {
        width: (item = resTab.tblResolution.item(resIdx, 1)) != null ? parseInt(item.text()) : 0,
        height: (item = resTab.tblResolution.item(resIdx, 2)) != null ? parseInt(item.text()) : 0,
      }
    }

    var exportPalettes = ObjUtil.fromEntries(gameExport.paletteVariations
      .map(function (paletteVariation, paletteIdx) {
        var checkbox = paletteTab.variationList.item(paletteIdx);
        return { key: paletteVariation.uiName, value: { exclude: checkbox.checkState() == Qt.Unchecked } };
      }));

    return {
      savingPath: ui.gbDirectory.savingPath.text,
      savingName: ui.gbDirectory.savingName.text,
      useSceneMarkers: ui.gbStage.chkSeparateFiles.checked,
      unitScalePreset: projectTab.cbUnitScalePreset.currentText,
      unitScale: projectTab.sbUnitScale.value,
      maxWidth: sheetTab.sbMaxWidth.value,
      maxHeight: sheetTab.sbMaxHeight.value,
      resolutionType: /**@type Settings["resolutionType"]*/(sheetTab.cbResType.currentText),
      fixResolution: sheetTab.rbFixed.checked,
      reuseFrames: sheetTab.cbReuseFrames.checked,
      reuseFramesThreshold: sheetTab.sbThreshold.value,
      spriteResolutions: spriteResolutions,
      precalculateBezier: ui.chkPreBez.checked,
      individualSprites: ui.chkIndividualSprites.checked,
      excludeEmptyDrawings: ui.chkExcludeEmptyDrawings.checked,
      encodeToTBG: ui.chkTBG.checked,
      includeOverlayAndUnderlay: ui.chkIncludeOverUnder.checked,
      overwriteProject: ui.chkOverwriteProject.checked,
      clearTextureFolder: ui.chkClearTextureFolder.checked,
      exportPalettes: exportPalettes,
      bakeAllGroups: false,
    };
  }

  /**
   * Execute callback with UI's updated settings when Export button is clicked.
   * @param {(settings: Settings, ui: {}) => void} callback
   */
  this.onExportClicked = function (callback) {
    var self = this;
    ui.btnExport.clicked.connect(function () {
      ui.setEnabled(false);
      callback(self.updatedSettings(), ui);
      ui.close();
    });
    return self;
  }
}

exports.open = function () {
  if (!ValidationChecks.validate({ bakeAllGroups: false }))
    return;
  var loadedSettings = loadSettings();
  var updatedSettings = new GameExportUI(loadedSettings)
    .onExportClicked(function (settings, ui) {
      var progressBar;
      try
      {
        // Check for dirty project
        if (scene.isDirty())
        {
          var result = MessageBox.warning(translator.tr("Project is not saved. Do you want to save and continue?"), MessageBox.Ok, MessageBox.Cancel);
          if (result == MessageBox.Ok)
            scene.saveAll();
          else if (result == MessageBox.Cancel)
            return;
        }
        if ("resetPalettes" in Utransform)
          Utransform.resetPalettes();
        progressBar = new ProgressBar(false, ui);
        var gameExport = new GameExport(settings, progressBar);
        gameExport
          .tryExportAudio()
          .tryRenderSprites()
          .trySaveXMLFiles()
          .complete();
      }
      catch (e)
      {
        MessageLog.trace("Process was interrupted: " + e);
      }
      finally
      {
        if (progressBar != null)
          progressBar.close();
      }
    })
    .exec()
    .updatedSettings();
  saveSettings(updatedSettings)
}
