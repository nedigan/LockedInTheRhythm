var NodeUtil = require("./TB_NodeUtil.js");
var Iter = require("./TB_Iter.js").Iter;

/**
 * @type {{ problem: string, suggestion: string, evaluate: (settings: { bakeAllGroups: boolean }) => { affected?: NodePath[], selected: NodePath }[], resolve?: (nodeSelection: NodePath[]) => string}[]} nodeSelection
 */
var exportRules = [
  {
    problem: translator.tr("Unsupported node found outside of bake_group"),
    suggestion: translator.tr("Move unsupported node into bake_group"),
    evaluate: function (settings) {
      var writePath = scene.getDefaultDisplay();
      if (writePath == null)
        return [];
      var invalidNodes = new NodeUtil.InputScan(writePath, {
        shouldEnterGroupNode: NodeUtil.notABakeGroupOrDisabledFunc(settings),
        isMatch: function (nodePath) {
          return NodeUtil.getNodeGameTag(settings, nodePath) == "invalid";
        }
      }).toArray();
      if (invalidNodes.length == 0)
        return [];
      MessageLog.trace("Invalid nodes: " + invalidNodes.map(function (nodePath) { return node.type(nodePath); }).join(", "));
      return invalidNodes.map(function (nodePath) { return { selected: nodePath }; });
    }
  },
  {
    problem: translator.tr("Single peg node required at the top of the node graph"),
    suggestion: translator.tr("Create a new master peg and assign all current top nodes to it"),
    evaluate: function (settings) {
      var topNodes = NodeUtil.findTopNodes(settings);
      if (topNodes.length == 1)
        if (node.type(topNodes[0]) == "PEG")
          return [];
        else
          return [{ selected: topNodes[0], affected: topNodes }];
      return topNodes.map(function (nodePath) { return { selected: nodePath, affected: topNodes }; });
    },
    resolve: function (nodeSelection) {
      var coord = {
        x: node.coordX(nodeSelection[0]),
        y: node.coordY(nodeSelection[0]),
        z: node.coordZ(nodeSelection[0]),
      };
      var masterPegPath = node.add(node.root(), "Master-P", "PEG", coord.x, coord.y - 100, coord.z + 1);
      nodeSelection.forEach(function (nodePath) {
        node.link(masterPegPath, 0, nodePath, 0);
      });
      return translator.tr("Added new master peg");
    }
  },
  {
    problem: translator.tr("Composite requires Passthrough mode"),
    suggestion: translator.tr("Reassign Composite to Passthrough mode"),
    evaluate: function (settings) {
      var writePath = scene.getDefaultDisplay();
      if (writePath == null)
        return [];
      var passThroughCompositesWithParentComposites = new NodeUtil
        .InputScan(writePath, {
          shouldEnterGroupNode: NodeUtil.notABakeGroupOrDisabledFunc(settings),
          isMatch: function (nodePath, branchSearchState) {
            var isComposite = node.type(nodePath) == "COMPOSITE";
            return {
              searchState: {
                feedsIntoComposite:
                  isComposite
                  || branchSearchState.feedsIntoComposite
              },
              match:
                isComposite
                && branchSearchState.feedsIntoComposite
                && node.getTextAttr(nodePath, 1, "COMPOSITE_MODE") != translator.tr("Pass Through"),
            };
          }
        }, { feedsIntoComposite: false })
        .toArray();
      return passThroughCompositesWithParentComposites
        .map(function (nodePath) { return { selected: nodePath }; });
    },
    resolve: function (nodeSelection) {
      nodeSelection.forEach(function (nodePath) {
        node.setTextAttr(nodePath, "COMPOSITE_MODE", 1, "compositePassthrough");
      });
      return translator.tr("Reassigned Composite to Passthrough mode");
    },
  }, {
    problem: translator.tr("Cutters cannot receive other Cutters as input"),
    suggestion: translator.tr("Move unsupported structure into bake_group"),
    evaluate: function (settings) {
      var writePath = scene.getDefaultDisplay();
      if (writePath == "Unconnected_Display")
        return [];
      var cuttersWithParentCutters = new NodeUtil
        .InputScan(writePath, {
          shouldEnterGroupNode: NodeUtil.notABakeGroupOrDisabledFunc(settings),
          isMatch: function (nodePath, branchSearchState) {
            var isCutter = node.type(nodePath) == "CUTTER";
            return {
              searchState: {
                feedsIntoCutter:
                  isCutter
                  || branchSearchState.feedsIntoCutter
              },
              match:
                isCutter
                && branchSearchState.feedsIntoCutter,
            };
          }
        }, { feedsIntoCutter: false })
        .toArray();
      return cuttersWithParentCutters
        .map(function (nodePath) { return { selected: nodePath }; });
    }
  }, {
    problem: translator.tr("Pegs cannot recieve Deformations as input"),
    suggestion: translator.tr("Add a Kinematic Output node between the Peg and Deformation"),
    evaluate: function (settings) {
      var writePath = scene.getDefaultDisplay();
      if (writePath == "Unconnected_Display")
        return [];
      var deformationsAbovePegs = new NodeUtil
        .InputScan(writePath, {
          shouldEnterGroupNode: NodeUtil.notABakeGroupOrDisabledFunc(settings),
          isMatch: function (nodePath, branchSearchState) {
            var nodeType = node.type(nodePath);
            var isPeg = nodeType == "PEG";
            var isKinematicOutput = nodeType == "KinematicOutputModule";
            var isDeformer = nodeType == "GameBoneModule"
              || nodeType == "BoneModule"
              || nodeType == "BendyBoneModule";
            return {
              searchState: { feedsIntoPeg: !isKinematicOutput && (isPeg || branchSearchState.feedsIntoPeg) },
              match: isDeformer && branchSearchState.feedsIntoPeg
            };
          }
        }, { feedsIntoPeg: false })
        .toArray();
      return deformationsAbovePegs
        .map(function (nodePath) { return { selected: nodePath }; });
    },
  },
];

// TODO: Implement more rules.
// }, {
//   problem: translator.tr("bake_group found with more than one input Transformation"),
//   suggestion: translator.tr("Remove all but one input Transformation from bake_group"),
// }, {
//   problem: translator.tr("bake_group found with more than one output Image"),
//   suggestion: translator.tr("Remove all but one output Image from bake_group"),
// }, {
//   problem: translator.tr("All cutter inputs must be deformed together"),
//   suggestion: translator.tr("Assign all cutter inputs to the same Deformer"),
// }, {

/**
 * @param {{ bakeAllGroups: boolean }} settings
 * @param {Record<string, boolean>} ignoredNodes
 */
function getIssues(settings, ignoredNodes) {
  return new Iter(exportRules)
    .flatMap(function (rule) {
      var issues = rule.evaluate ? rule.evaluate(settings) : [];
      return issues
        .map(function (issue) {
          if (ignoredNodes[issue.selected])
            return null;
          var affected = issue.affected != null
            ? issue.affected.filter(function (nodePath) { return !ignoredNodes[nodePath]; })
            : [issue.selected];
          if (affected.length == 0)
            return null;
          return {
            problem: rule.problem,
            suggestion: rule.suggestion,
            resolve: rule.resolve,
            selected: issue.selected,
            affected: affected,
          };
        })
        .filter(Iter.notNull);
    })
    .filter(Iter.notNull);
}

/**
 * @param {{bakeAllGroups: boolean }} settings 
 * @returns 
 */
exports.validate = function (settings) {
  var issues = getIssues(settings, {});
  var ignoredNodes = /**@type {Record<string, boolean>}*/({});
  var cancelled = false;
  var issue;
  while ((issue = issues.shift()) != null && !cancelled)
  {
    var selected = issue.selected;
    var affected = issue.affected;

    // Select all nodes relating to this issue.
    selection.clearSelection();
    selection.addNodeToSelection(selected);
    Action.performForEach("onActionFocusOnSelectionNV()", "Node View");

    // Start UI for the issue.
    var ui = UiLoader.load("TB_ValidationChecks.ui");
    ui.windowTitle += " (" + issues.length + translator.tr(" issues remaining)");
    ui.lblProblem.text = translator.tr("Problem - ") + issue.problem;
    ui.lblSuggestion.text = translator.tr("Suggestion - ") + issue.suggestion;
    ui.lblAffectedNodes.text = translator.tr("Affected Nodes:\n") + issue.affected.join("\n");

    // Handle UI buttons.
    var skip = false;
    cancelled = true;
    if (issue.resolve == undefined)
    {
      ui.btnResolve.setEnabled(false);
    }
    else
    {
      var resolve = issue.resolve;
      ui.btnResolve.clicked.connect(function () {
        ui.close();
        scene.beginUndoRedoAccum(translator.tr("Render Node"));
        var resolution = resolve(affected);
        scene.endUndoRedoAccum();
        MessageBox.information(translator.tr("Suggestion applied - ") + resolution);
        cancelled = false;
      });
    }
    ui.btnNextIssue.clicked.connect(function () {
      ui.close();
      skip = true;
      cancelled = false;
    });
    ui.btnIgnore.clicked.connect(function () {
      ui.close();
      cancelled = false;
      ignoredNodes[selected] = true;
    });
    ui.btnCancel.clicked.connect(function () {
      ui.close();
    });

    // Show UI.
    ui.exec();

    // If the user didn't cancel or skip to next issue, get the next set of issues.
    if (!cancelled && !skip)
    {
      issues = getIssues(settings, ignoredNodes);
    }
    else if (skip)
    {
      issues.push(issue);
    }
  }

  return !cancelled;
}