/*
 * Copyright Toon Boom Animation Inc - 2022
 */

var ObjUtil = require("./TB_ObjUtil.js");
var Iter = require("./TB_Iter.js").Iter;

/**
 * @param {NodePath} nodePath
 */
exports.nodePath = function (nodePath) {
  return nodePath.split("/").slice(1).join("_");
}

/**
* @param {NodePath} nodePath
*/
exports.nodePathToPivot = function (nodePath) {
  return exports.nodePath(nodePath) + "_Pivot";
}

/**
 * @param {string} name
 */
exports.performanceTimer = function (name) {
  var totalTime = 0;
  var startTime = 0;
  return {
    start: function () {
      startTime = Date.now();
    },
    stop: function () {
      var endTime = Date.now();
      totalTime += endTime - startTime;
    },
    print: function () {
      MessageLog.trace(name + ": " + totalTime + "ms");
    }
  }
}

/**
 * @param {{ bakeAllGroups: boolean }} settings
 */
exports.notABakeGroupFunc = function (settings) {
  return function (/**@type NodePath*/ nodePath) {
    return exports.getNodeGameTag(settings, nodePath) != "bake"
  };
}
/**
 * @param {{ bakeAllGroups: boolean }} settings
 */
exports.notABakeGroupOrDisabledFunc = function (settings) {
  var notABakeGroup = exports.notABakeGroupFunc(settings);
  return function (/**@type NodePath*/nodePath) {
    return notABakeGroup(nodePath) && node.getEnable(nodePath);
  };
};

/**
 * @param {{ bakeAllGroups: boolean }} settings
 */
exports.findTopNodes = function (settings) {
  var writePath = scene.getDefaultDisplay();
  if (writePath == null)
    return [];
  return new exports.InputScan(writePath, {
    shouldEnterGroupNode: function () { return false; },
    isMatch: function (nodePath) {
      if (!node.getEnable(nodePath))
        return false;
      for (var i = 0; i < node.numberOfInputPorts(nodePath); i++)
      {
        var parent = node.srcNode(nodePath, i);
        if (parent != null && parent.length > 0)
          return false;
      }
      return exports.getNodeGameTag(settings, nodePath) != "ignored";
    }
  }).toArray();
}

/**
 * Starting from a node path, search upwards through node graph inputs, collecting nodes that match criteria.
 * Optionally, a persistent state can be passed to the search, which is tracked per-branch explored, to discover deep parent-child relationships.
 * @param {NodePath} outputPath
 * @param {{
 *    shouldEnterGroupNode?: (nodePath: NodePath) => boolean,
 *    isMatch?: (nodePath: NodePath, searchState: T) => boolean | { match: boolean, searchState: T },
 *    shouldQuitBranch?: (nodePath: NodePath, inputPort: number) => boolean,
 * }=} callbacks
 * @param {T} [searchState]
 * @template T
 */
exports.InputScan = function (outputPath, callbacks, searchState) {
  /** @type {Record<NodePath, boolean>} */
  var resultNodeLookup = {};
  var unparsedNodes = [{ nodePath: outputPath, searchState: searchState }];
  var unparsed;
  while (unparsed = unparsedNodes.pop())
  {
    var branchSearchState = unparsed.searchState;
    // Check if this is a match.
    {
      var isMatch = true;
      if (callbacks != null
        && callbacks.isMatch != null)
      {
        var result = callbacks.isMatch(unparsed.nodePath, /**@type T*/(unparsed.searchState));
        if (typeof result == "boolean")
          isMatch = result;
        else
        {
          isMatch = result.match;
          branchSearchState = result.searchState;
        }
      }
      if (isMatch)
      {
        resultNodeLookup[unparsed.nodePath] = true;
      }
    }
    // Add inputs to unparsed list.
    for (var i = 0; i < node.numberOfInputPorts(unparsed.nodePath); i++)
    {
      var inputNodePath = node.srcNode(unparsed.nodePath, i);
      if (callbacks == null
        || callbacks.shouldEnterGroupNode == null
        || callbacks.shouldEnterGroupNode(inputNodePath))
      {
        inputNodePath = node.flatSrcNode(unparsed.nodePath, i);
      }
      if (inputNodePath == node.noNode()) continue;
      if (callbacks == null
        || callbacks.shouldQuitBranch == null
        || !callbacks.shouldQuitBranch(unparsed.nodePath, i))
      {
        unparsedNodes.unshift({ nodePath: inputNodePath, searchState: branchSearchState });
      }
    }
  }

  this.toLookup = function () {
    return resultNodeLookup;
  }

  this.toArray = function () {
    return ObjUtil.keys(resultNodeLookup);
  }
}

/**
 * Starting from a node path, search downwards through node graph outputs, collecting nodes that match criteria
 * @param {NodePath} inputPath
 * @param {{
 *    shouldEnterGroupNode?: ((nodePath: NodePath) => boolean);
 *    isMatch?: (nodePath: NodePath) => boolean;
 * }} [callbacks]
 */
exports.OutputScan = function (inputPath, callbacks) {
  /**@type {Record<NodePath, boolean>}*/
  var resultNodeLookup = {};
  var unparsedNodes = [inputPath];
  var nodePath;
  while (nodePath = unparsedNodes.pop())
  {
    var outputPorts = node.numberOfOutputPorts(nodePath);
    for (var outputPort = 0; outputPort < outputPorts; outputPort++)
    {
      var outputLinks = node.numberOfOutputLinks(nodePath, outputPort);
      for (var outputLink = 0; outputLink < outputLinks; outputLink++)
      {
        var outputNodePath = node.dstNode(nodePath, outputPort, outputLink);
        while (node.isGroup(outputNodePath)
          && (callbacks == null
            || callbacks.shouldEnterGroupNode == null
            || callbacks.shouldEnterGroupNode(outputNodePath)
          ))
        {
          outputNodePath = /**@type NodePath*/(outputNodePath + "/Multi-Port-In");
        }
        if (outputNodePath == node.noNode()) continue;
        if (node.type(outputNodePath) == "MULTIPORT_OUT")
        {
          outputNodePath = node.parentNode(outputNodePath);
        }
        unparsedNodes.unshift(outputNodePath);
      }
    }
    if (callbacks == null || callbacks.isMatch == null || callbacks.isMatch(nodePath))
    {
      resultNodeLookup[nodePath] = true;
    }
  }
  this.toLookup = function () {
    return resultNodeLookup;
  }
  this.toArray = function () {
    return ObjUtil.keys(resultNodeLookup);
  }
}

/**
 * @param {NodePath} inputPath
 */
exports.immediateOutputNodes = function (inputPath) {
  var immediteOutputNodes = /**@type NodePath[]*/([]);
  var outputPorts = node.numberOfOutputPorts(inputPath);
  for (var outputPort = 0; outputPort < outputPorts; outputPort++)
  {
    var outputLinks = node.numberOfOutputLinks(inputPath, outputPort);
    for (var outputLink = 0; outputLink < outputLinks; outputLink++)
    {
      var outputNodePath = node.dstNode(inputPath, outputPort, outputLink);
      immediteOutputNodes.push(outputNodePath);
    }
  }
  return immediteOutputNodes;
}

/**
 * @param {UniqueNodePath} uniqueNodePath
 */
exports.decomposeUniqueNode = function (uniqueNodePath) {
  var dashSplit = uniqueNodePath.split("-");
  return {
    uid: dashSplit[0].slice(1),
    nodePath: /**@type NodePath*/(dashSplit.slice(1).join("-")),
  };
}

/**
 * @param {string} uid
 * @param {NodePath} nodePath
 */
exports.uniqueNodePath = function (uid, nodePath) {
  return /**@type UniqueNodePath*/("#" + uid + "-" + nodePath);
}

exports.bakePrefix = "bake_";

var nodeCategories = {
  read: ["READ"],
  cutter: ["CUTTER", "CUTTER-MASK"],
  peg: ["PEG"],
  kinematic: ["KinematicOutputModule"],
  bone: ["BendyBoneModule", "GameBoneModule"],
  ignored: ["COMPOSITE", "DeformationCompositeModule", "WRITE", "DISPLAY", "COLOR_CARD"],
};

/**
 * @param {{ bakeAllGroups: boolean }} settings
 * @param {NodePath} nodePath
 * @returns {GameNodeTag}
 */
exports.getNodeGameTag = function (settings, nodePath) {
  if (nodePath == node.noNode()) return "noNode";
  if (node.isGroup(nodePath) && (settings.bakeAllGroups || (node.getName(nodePath).substring(0, exports.bakePrefix.length) == exports.bakePrefix)))
    return "bake";
  var categoryKeys = ObjUtil.keys(nodeCategories);
  var nodeType = node.type(nodePath);
  if (nodeType == "CUTTER" && node.getTextAttr(nodePath, 1.0, "inverted") == "Y")
  {
    return "inverseCutter";
  }
  for (var i = 0; i < categoryKeys.length; i++)
  {
    var categoryKey = categoryKeys[i];
    if (nodeCategories[categoryKey].indexOf(nodeType) >= 0) return categoryKey;
  }
  return "invalid";
}

/**
 * @param {{ bakeAllGroups: boolean }} settings
 * @param {UniqueNodePath} nodePath
 * @returns {GameNodeTag}
 */
exports.getUniqueNodeGameTag = function (settings, nodePath) {
  return exports.getNodeGameTag(settings, exports.decomposeUniqueNode(nodePath).nodePath);
}

/**
 * @param {{ bakeAllGroups: boolean }} settings
 * @param {NodePath} nodePath
 */
exports.getNodeInfo = function (settings, nodePath) {
  return {
    path: nodePath,
    type: node.type(nodePath),
    category: exports.getNodeGameTag(settings, nodePath),
  }
}

/**
 * @param {"WRITE" | "DISPLAY"} type
 * @param {NodePath} layerPath
 * @returns {NodePath | undefined}
 */
exports.findFirstNodeOfType = function (type, layerPath) {
  var groups = /**@type {NodePath[]}*/([]);
  for (var i = 0; i < node.numberOfSubNodes(layerPath); ++i)
  {
    var nodePath = node.subNode(layerPath, i);
    if (node.type(nodePath) == type)
    {
      return nodePath;
    }
    if (node.isGroup(nodePath))
    {
      groups.push(nodePath);
    }
  }
  for (var i = 0; i < groups.length; ++i)
  {
    var result = exports.findFirstNodeOfType(type, groups[i]);
    if (result != null)
      return result;
  }
}

/**
 * Special node parsing procedure for gathering skeleton nodes.
 * Parsing is done in 'chains' from the source to the root.
 * Chains that 'cross-over' require duplicate nodes so that final structure has no crossing links (required for composite ordering).
 * Doing so requires the introduction of "UniqueNodePath"s for use as keys in later Hashmap lookups.
 * @param {{ bakeAllGroups: boolean }} settings
 * @param {NodePath} outputPath
 * @param {UncrossCallbacks} callbacks
 * @returns {Link[]}
 */
exports.uncrossLinks = function (settings, outputPath, callbacks) {

  /**
   * @typedef {{ nodePath: `Top/${string}` }} InputToNode
   * @typedef {{ input: InputToNode, ancestorInputs: InputToNode[] }} ChainSource
   * @type {Array<ChainSource>}
   **/
  var chainSources = [{
    input: {
      nodePath: outputPath,
    },
    ancestorInputs: [],
  }]
  var chainSource;
  /**@type Lookup<NodePath, UniqueNodePath>*/
  var currentNodePathLookup = {};
  /**@type Lookup<UniqueLink, true?>*/
  var uniqueLinks = {};
  var chainIdx = 0;
  while (chainSource = chainSources.pop())
  {
    var input = chainSource.input;
    var pathChain = chainSource.ancestorInputs
      .map(function (input) {
        return {
          input: input,
          siblingInputs:  /**@type Array<InputToNode>*/([]),
        };
      });
    while (true) // We break from loop if no inputs found.
    {
      var inputNodePaths = getNextInputNodePaths(input.nodePath, callbacks);
      // Break from loop if no inputs found.
      if (inputNodePaths.length == 0)
      {
        pathChain.push({ input: input, siblingInputs: [] });
        break;
      }
      pathChain.push({ input: input, siblingInputs: inputNodePaths.slice(1) });
      input = inputNodePaths[0];
    }
    var additionalSources = new Iter(pathChain)
      .flatMap(function (link, linkIndex) {
        return link.siblingInputs
          .map(function (inputNodePath) {
            return {
              input: inputNodePath,
              ancestorInputs: pathChain.slice(0, linkIndex + 1)
                .filter(function (link) { return callbacks.isMatch == null || callbacks.isMatch(link.input.nodePath) })
                .map(function (link) { return link.input; }),
            };
          })
          .reverse();
      });
    chainSources = chainSources.concat(additionalSources);
    var nextNodePathToUnique = /**@type Lookup<NodePath, UniqueNodePath>**/({})
    var validPathChain = pathChain
      .filter(function (link) { return callbacks.isMatch == null || callbacks.isMatch(link.input.nodePath) })
    validPathChain
      .reverse()
      .forEach(function (link, linkIndex) {
        var nodePath = link.input.nodePath;
        var parentPath = linkIndex == 0 ? /**@type NodePath*/("Top") : validPathChain[linkIndex - 1].input.nodePath;
        var uniqueNodePath = currentNodePathLookup[nodePath] || exports.uniqueNodePath("" + chainIdx, nodePath);
        var uniqueParentPath = currentNodePathLookup[parentPath] || exports.uniqueNodePath("" + chainIdx, parentPath);
        nextNodePathToUnique[nodePath] = uniqueNodePath;
        nextNodePathToUnique[parentPath] = uniqueParentPath;
        uniqueLinks[/**@type UniqueLink*/(uniqueParentPath + " -> " + uniqueNodePath)] = true;
      })
    currentNodePathLookup = nextNodePathToUnique
    chainIdx++;
  }
  return ObjUtil.entries(uniqueLinks)
    .map(function (uniqueLink) {
      var uniqueLinkSplit = uniqueLink.key.split(" -> ");
      var parentPath = /**@type UniqueNodePath*/(uniqueLinkSplit[0]);
      var nodePath = /**@type UniqueNodePath*/(uniqueLinkSplit[1]);
      return {
        "in": parentPath,
        "out": {
          tag: exports.getUniqueNodeGameTag(settings, nodePath),
          nodePath: nodePath,
          inputPort: 0,
        },
      };
    });
}

/**
 * @param {NodePath} nodePath
 * @param {UncrossCallbacks} callbacks
 * @returns {Array<InputToNode>}
 */
function getNextInputNodePaths(nodePath, callbacks) {
  var inputNodePaths = /**@type Array<InputToNode>*/ ([]);
  var inputPorts = node.numberOfInputPorts(nodePath);
  for (var inputPort = inputPorts - 1; inputPort >= 0; inputPort--)
  {
    var inputNode = node.srcNode(nodePath, inputPort);
    var nextInput = {
      nodePath: inputNode,
      port: inputPort,
    };
    if (callbacks == null
      || callbacks.shouldEnterGroupNode == null
      || callbacks.shouldEnterGroupNode(nextInput.nodePath))
    {
      inputNode = node.flatSrcNode(nodePath, inputPort);
      nextInput = {
        nodePath: inputNode,
        port: inputPort,
      };
    }
    if (nextInput.nodePath == node.noNode())
      continue;
    inputNodePaths.push(nextInput);
  }
  return inputNodePaths;
}

/**
 * Depth-first search from output node, collecting all nodes that are connected to the output node.
 * Special consideration is made for group nodes, which are traversed into if the callback allows.
 * @param {{ bakeAllGroups: boolean }} settings
 * @param {NodePath} outputPath
 * @param {LinkGeneratorCallbacks} callbacks
 * @returns {Link[]}
 */
exports.generateRenderSortedLinks = function (settings, outputPath, callbacks) {
  /** @type {Record<NodePath, true?>} */
  var nodePathRegistedToDuplicate = {};
  /** @type {Record<NodePath, UniqueNodePath?>} */
  var nodePathToUnique = {};
  var nextBranchSources = getNextInputNodePaths(outputPath, callbacks).map(function (input) {
    return {
      nodePath: exports.uniqueNodePath("0", outputPath),
      isMatch: false,
      isVisible: true,
      input: input
    };
  });

  /**
   * @param {NonNullable<typeof branch>} branch
   */
  function tryDeferBranch(branch) {
    var nodePath = exports.decomposeUniqueNode(branch.nodePath).nodePath;
    var shouldDefer = callbacks.shouldDeferInputToSeperateChain == null || callbacks.shouldDeferInputToSeperateChain(nodePath, branch.input.port, branch.input.nodePath);
    if (shouldDefer)
    {
      nextBranchSources.push({
        nodePath: branch.nodePath,
        isMatch: branch.isMatch,
        isVisible: branch.isVisible,
        input: branch.input,
      });
    }
    return shouldDefer;
  }

  var infiniteLoopCount = 0;
  /** @type {typeof nextBranchSources | undefined} */
  var branchSources;
  /** @type {NonNullable<typeof branchSources>[number] | undefined} */
  var branch;
  /** @type {Link[][]} */
  var linksPerBranch = [];
  while (nextBranchSources.length > 0)
  {
    // Swap branch sources to next branch sources (deferred branches).
    branchSources = nextBranchSources
    nextBranchSources = [];
    while (branch = branchSources.pop())
    {
      var links = [];
      while (true)
      {
        // Infinite loop detection.
        infiniteLoopCount++;
        if (infiniteLoopCount > 10000)
        {
          throw Error("Infinite loop detected in generateRenderSortedLinks");
        }

        // Check if branch heads into invisibility.
        var isVisible = callbacks.branchIsVisible == null || branch.isVisible && callbacks.branchIsVisible(exports.decomposeUniqueNode(branch.nodePath).nodePath, branch.input.port);

        // Find existing unique node path for this branch step - in some cases, this may be dropped if the the node opts to duplicate.
        var existingNodePath = nodePathToUnique[branch.input.nodePath];
        {
          var shouldDuplicate = callbacks.shouldDuplicateNode != null && callbacks.shouldDuplicateNode(branch.input.nodePath, isVisible);

          var requiresNewUniqueNodePath = shouldDuplicate && nodePathRegistedToDuplicate[branch.input.nodePath];
          if (requiresNewUniqueNodePath)
            existingNodePath = null;

          if (shouldDuplicate)
            nodePathRegistedToDuplicate[branch.input.nodePath] = true;
        }

        // Build link for this branch step.
        var inputUniqueNodePath = existingNodePath || exports.uniqueNodePath("" + linksPerBranch.length, branch.input.nodePath); // !requiresNewUniqueNodePath && 
        var isMatch = callbacks.isMatch == null || callbacks.isMatch(branch.input.nodePath);
        if (isMatch && branch.isMatch)
          links.push({
            "in": inputUniqueNodePath,
            "out": {
              tag: exports.getUniqueNodeGameTag(settings, branch.nodePath),
              nodePath: branch.nodePath,
              inputPort: branch.input.port,
            },
          });

        // Quit early if we have re-joined to a previous branch.
        if (existingNodePath != null)
          break;

        // Track unique node path for this branch step.
        nodePathToUnique[branch.input.nodePath] = inputUniqueNodePath;

        // Get the next inputs to explore, quit early if none found.
        var inputNodePaths = getNextInputNodePaths(branch.input.nodePath, callbacks);
        if (inputNodePaths.length == 0)
          break;

        // Ready next branch step with the first input.
        branch.input = inputNodePaths[0];
        if (isMatch)
          branch.nodePath = inputUniqueNodePath;
        branch.isMatch = branch.isMatch || isMatch;
        branch.isVisible = isVisible;

        // Enqueue all other inputs to be explored as separate branches.
        /** @type {NonNullable<typeof branch>} */
        var lastBranch = branch;
        branchSources = branchSources.concat(inputNodePaths
          .slice(1)
          .map(function (input) {
            return {
              nodePath: lastBranch.nodePath,
              isMatch: lastBranch.isMatch,
              isVisible: lastBranch.isVisible,
              input: input,
            };
          })
          .filter(function (branch) {
            return !tryDeferBranch(branch);
          })
          .reverse());

        // Try deferring the current branch step to another pass, or continue with this branch.
        if (tryDeferBranch(branch))
          break;
      }
      linksPerBranch.push(links);
    }
  }

  var allLinks = new Iter(linksPerBranch).flatMap(function (links) { return links.reverse(); });
  allLinks = [{
    "in": /**@type UniqueNodePath*/("#0-Top"),
    "out": {
      tag: exports.getUniqueNodeGameTag(settings, allLinks[0]["in"]),
      nodePath: allLinks[0]["in"],
      inputPort: 0,
    }
  }].concat(allLinks);
  return allLinks;
}

var artLayers = /**@type const*/([
  { index: 0, readAttr: "READ_UNDERLAY", modeAttr: "UNDERLAY_ART_DRAWING_MODE" },
  { index: 1, readAttr: "READ_LINE_ART", modeAttr: "LINE_ART_DRAWING_MODE" },
  { index: 2, readAttr: "READ_COLOR_ART", modeAttr: "COLOR_ART_DRAWING_MODE" },
  { index: 3, readAttr: "READ_OVERLAY", modeAttr: "OVERLAY_ART_DRAWING_MODE" }]);

/**
 * @param {NodePath} nodePath
 * @param {number} timelineFrame
 * @returns {boolean}
 * Given a read node, determine if it is visible at a given frame.
 * This is done by checking if any art layers are visible, or if the drawing a bitmap or is not a tvg file.
 **/
exports.isReadNodeVisible = function (nodePath, timelineFrame) {
  // Consider all non-tvg files to have some visible art.
  {
    var columnName = node.linkedColumn(nodePath, "DRAWING.ELEMENT");
    var elementId = column.getElementIdOfDrawing(columnName);
    var nameOrExposure = column.getEntry(columnName, 1, timelineFrame);
    if (nameOrExposure == null || nameOrExposure.length == 0)
      return false;
    var sourceFilename = Drawing.filename(elementId, nameOrExposure);
    var tvgSuffixCandidate = sourceFilename.slice(-4).toLowerCase();
    if (tvgSuffixCandidate != ".tvg")
    {
      MessageLog.trace("Non-tvg file: " + nameOrExposure + " " + elementId + " " + nodePath);
      return true;
    }
  }

  // Check if any art layers are visible.
  var drawingRequest = { node: nodePath, frame: timelineFrame };
  return artLayers.some(function (artLayer) {
    if (node.getTextAttr(nodePath, 1, artLayer.readAttr) == "N")
      return false;
    if (node.getTextAttr(nodePath, 1, artLayer.modeAttr) == "Bitmap")
      return true;
    var numberOfLayers = Drawing.query.getNumberOfLayers({
      drawing: drawingRequest,
      art: artLayer.index,
    });

    if (numberOfLayers > 0)
      return true;
    return false;
  });
}

/**@type Record<string, boolean>**/
var seperateAttributes = {
  "X": true,
  "Y": true,
  "Z": true,
}
/**@type Record<string, boolean>**/
var nonSeperateAttributes = {
  "XY": true,
  "XYZ": true,
}
var indexToSubattribute = ["X", "Y", "Z"];

/**
 * @param {NodePath} nodePath
 * @param {{ precalculateBezier?: boolean, attributeWhitelist?: Lookup<string, true>}} settings
 */
exports.findModifiedAttributesForNode = function (nodePath, settings) {
  var modifiedAttributes = /**@type AttributeInfo[]*/([]);
  // Collect all drawing nodes that could affect pivot.
  var attr = node.getAttr(nodePath, 1, "USE_DRAWING_PIVOT");
  var drawingNodesThatAffectPivot = [attr != null && attr.intValue() == 2 ? nodePath : null] // 2 = "Apply Embedded Pivot on Drawing Layer"
    .concat(exports
      .immediateOutputNodes(nodePath)
      .map(function (outputNode) {
        var attr = node.getAttr(outputNode, 1, "USE_DRAWING_PIVOT");
        return attr != null && attr.intValue() == 1 ? outputNode : null; // 1 = "Apply Embedded Pivot on Parent Peg"
      }))
    .filter(Iter.notNull);
  // If something is affecting the pivot, then we need to get the pivot at every frame.
  if (drawingNodesThatAffectPivot.length > 0)
  {
    var pivotAtFrame = []
    var previousPivot = /**@type {{ x: number, y: number, z: number } | null}*/(null);
    for (var i = 1; i <= frame.numberOf(); i++)
    {
      var pivot = node.getPivot(nodePath, i);
      if (previousPivot == null || pivot.x != previousPivot.x || pivot.y != previousPivot.y)
      {
        pivotAtFrame.push({ x: pivot.x, y: pivot.y, z: pivot.z, start: i });
        previousPivot = pivot;
      }
    }
    modifiedAttributes.push({ path: "PIVOT", column: exports.nodePathToPivot(nodePath), curve: { type: "PIVOT", points: pivotAtFrame } });
  }
  // Just get the pivot on the first frame, as normally pivots are not animated
  else
  {
    var pivotAttr = node.getAttr(nodePath, 1, "PIVOT");
    if (pivotAttr != null)
    {
      var pivot = pivotAttr.pos3dValue();
      modifiedAttributes.push({ path: "PIVOT", column: exports.nodePathToPivot(nodePath), curve: { type: "PIVOT", points: [{ x: pivot.x, y: pivot.y, z: pivot.z, start: 1 }] } });
    }
  }
  var attributesToCheck = node.getAttrList(nodePath, 1)
    .map(function (attr) { return { attr: attr, path: "" } })
    .reverse();
  var candidate;
  while (candidate = attributesToCheck.pop())
  {
    try
    {
      var subAttributes = candidate.attr.getSubAttributes();
      var attrPath = candidate.path.length == 0
        ? candidate.attr.keyword()
        : candidate.path + "." + candidate.attr.keyword();
      if (subAttributes != null)
      {
        var seperateAttrIndex = new Iter(subAttributes)
          .findIndex(function (attr) { return attr.keyword() == "SEPARATE" });
        if (seperateAttrIndex != null)
        {
          var removeLookup = subAttributes[seperateAttrIndex].boolValue()
            ? nonSeperateAttributes
            : seperateAttributes;
          subAttributes = subAttributes
            .filter(function (attr) { return !removeLookup[attr.keyword()] });
        }
        subAttributes.forEach(function (attr) { attributesToCheck.unshift({ attr: attr, path: attrPath }) });
      }
      if (settings.attributeWhitelist != null && !settings.attributeWhitelist[attrPath])
      {
        continue;
      }
      var linkedColumn = node.linkedColumn(nodePath, attrPath);
      if (linkedColumn != null && linkedColumn.length > 0)
      {
        var curves = exports.parseColumnForCurves(nodePath, attrPath, linkedColumn, settings);
        if (curves.length == 1)
          modifiedAttributes.push({ path: attrPath, column: linkedColumn, curve: curves[0] });
        else
          curves.forEach(function (curve, index) {
            modifiedAttributes.push({
              path: attrPath + "." + indexToSubattribute[index],
              column: linkedColumn + "_" + indexToSubattribute[index],
              curve: curve
            });
          });
        continue;
      }
      var constantValue = parseFloat(node.getTextAttr(nodePath, 1, attrPath));
      if (!isNaN(constantValue) && constantValue != 0)
      {
        modifiedAttributes.push({ path: attrPath, constant: constantValue });
        continue;
      }
    }
    catch (e)
    {
      MessageLog.trace("Error finding modified attributes for " + nodePath + " - " + e);
    }
  }
  return modifiedAttributes;
}

/**
 * Provide a concise list of novel frames from multiple timelineToData arrays
 * @param {number[]} groupOfTimelineToData
 * @param {Array<(number | null)[] | undefined>} groupOfTimelineToDisplayData
 * @param {Array<{ timelineFrame: number, frameValues: (number | null)[] }>} uniqueFramesInfo
 */
exports.findUniqueFramesForDisplayData = function (groupOfTimelineToData, groupOfTimelineToDisplayData, uniqueFramesInfo) {
  var timelineToUniqueFrame = [];
  for (var timelineFrame = 0; timelineFrame < frame.numberOf(); timelineFrame++)
  {
    var currentFrameValues = groupOfTimelineToDisplayData
      .map(function (d) { return d == null ? null : d[timelineFrame] });
    if (currentFrameValues.every(function (d) { return d == null; }))
    {
      timelineToUniqueFrame.push(null);
      continue;
    }
    currentFrameValues.push(groupOfTimelineToData[timelineFrame]);
    var uniqueFrame = new Iter(uniqueFramesInfo)
      .findIndex(function (uniqueFrame) {
        return uniqueFrame.frameValues
          .every(function (uniqueValue, columnIndex) {
            var currentValue = currentFrameValues[columnIndex];
            return uniqueValue == currentValue;
          });
      });
    if (uniqueFrame == null)
    {
      uniqueFrame = uniqueFramesInfo.length;
      uniqueFramesInfo.push({ timelineFrame: timelineFrame, frameValues: currentFrameValues });
    };
    timelineToUniqueFrame.push(uniqueFrame);
  }

  return {
    timelineToUniqueFrame: timelineToUniqueFrame,
    uniqueFramesInfo: uniqueFramesInfo,
  };
}

/**
 * Provide a concise list of novel frames from multiple timelineToData arrays
 * @param {Array<number[]>} groupOfTimelineToData
 */
exports.findUniqueFramesForData = function (groupOfTimelineToData) {
  var uniqueFramesInfo = [];
  var timelineToUniqueFrame = [];
  for (var timelineFrame = 0; timelineFrame < frame.numberOf(); timelineFrame++)
  {
    var currentFrameValues = groupOfTimelineToData
      .map(function (d) { return d[timelineFrame] });
    var uniqueFrame = new Iter(uniqueFramesInfo)
      .findIndex(function (uniqueFrame) {
        return uniqueFrame.frameValues
          .every(function (uniqueValue, columnIndex) {
            var currentValue = currentFrameValues[columnIndex];
            return uniqueValue == currentValue;
          });
      });
    if (uniqueFrame == null)
    {
      uniqueFrame = uniqueFramesInfo.length;
      uniqueFramesInfo.push({ timelineFrame: timelineFrame, frameValues: currentFrameValues });
    };
    timelineToUniqueFrame.push(uniqueFrame);
  }
  return timelineToUniqueFrame;
}

/**
 * Retrieve values, either single, tuple or x/y/z
 * @param {NodePath} nodePath
 * @param {number} frame
 * @param {string} attrPath
 */
exports.getValuesFromAttrAtFrame = function (nodePath, frame, attrPath) {
  var rawText = node.getTextAttr(nodePath, frame, attrPath);
  var textValues;
  if (rawText.length == 0)
    textValues = ["X", "Y", "Z"].map(function (subAttr) {
      MessageLog.trace(attrPath + "." + subAttr);
      return node.getTextAttr(nodePath, frame, attrPath + "." + subAttr);
    })
  else
    textValues = rawText.split(" ");
  var result = textValues
    .map(parseFloat)
    .map(function (value) { return isNaN(value) ? 0 : value; });
  return result;
}

/**
 * Get list of points for column, disclose type of points returned
 * @param {NodePath} nodePath
 * @param {string} attrPath
 * @param {string} linkedColumn
 * @param {{ precalculateBezier?: boolean}} settings
 * @returns {Array<Curve | Stream>}
 */
exports.parseColumnForCurves = function (nodePath, attrPath, linkedColumn, settings) {
  var columnType = column.type(linkedColumn);
  switch (columnType)
  {
    case "EASE":
      // Easing is not supported from the engine-side, so we just bake out the values.
      var curve = exports.parseBezierForPoints(linkedColumn, { precalculateBezier: true });
      return [curve];
    case "BEZIER":
      if (!settings.precalculateBezier && func.numberOfPoints(linkedColumn) == 0)
        return [{ type: "LINEAR", points: [{ x: 1, y: parseFloat(node.getTextAttr(nodePath, 1, attrPath)) }] }];
      var curve = exports.parseBezierForPoints(linkedColumn, settings);
      return [curve];
    case "3DPATH":
      return exports.parse3DPathForPoints(linkedColumn, settings);
    case "DRAWING":
      return [exports.parseDrawingForValues(linkedColumn)];
  }
  return [];
}

/**
 * @param {number[]} valueAtIndex
 */
exports.processStreamContentsIntoLinearCurve = function (valueAtIndex) {
  return valueAtIndex
    // pack in the absolute index of this point
    .map(function (value, index) { return { value: value, index: index }; })
    // filter out null values and values that are the same as the previous AND the next value
    .filter(function (point, index, points) {
      return point.value != null
        &&
        (
          index == 0
          || index == points.length - 1
          || point.value != points[index - 1].value
          || point.value != points[index + 1].value);
    })
    .map(function (entry) {
      return {
        x: entry.index + 1,
        y: entry.value,
      };
    });
}

/**
 * Trim curve to a start/end time, offsetting all temporal elements per-point to originate at the start time. Processes RawData channels into consecutive curves.
 * @param {Curve | Stream} curve
 * @param {number} startTime
 * @param {number} length
 * @returns {Curve}
 */
exports.trimAndOffsetCurve = function (curve, startTime, length) {
  var endTime = startTime + length;
  var timings = curve.type == "PIVOT" ? curve.points.map(function (pivotPoint) { return pivotPoint.start })
    : curve.type == "3DPATH" ? curve.points.map(function (point) { return point.lockedInTime; })
      : curve.type == "LINEAR" || curve.type == "BEZIER"
        ? curve.points.map(function (point) { return point.x; })
        : curve.valueAtIndex.map(function (_, index) { return index + 1 });
  var firstValidIndex = 0;
  var lastValidIndex = timings.length;
  for (var i = 0; i < timings.length - 1; i++)
  {
    if (timings[i] <= startTime && timings[i + 1] > startTime)
    {
      firstValidIndex = i;
    }
    if (timings[i] < endTime && timings[i + 1] >= endTime)
    {
      lastValidIndex = i + 1;
    }
  }
  return curve.type == "PIVOT"
    ? {
      type: curve.type,
      points: curve.points
        .slice(firstValidIndex, lastValidIndex + 1)
        .map(function (pivotPoint) {
          return {
            x: pivotPoint.x,
            y: pivotPoint.y,
            z: pivotPoint.z,
            start: pivotPoint.start - startTime + 1,
          };
        }),
    }
    : curve.type == "STREAM"
      ? {
        type: "LINEAR",
        points: exports.processStreamContentsIntoLinearCurve(curve.valueAtIndex
          .slice(firstValidIndex, lastValidIndex + 1)
        )
        ,
      }
      : curve.type == "LINEAR"
        ? {
          type: curve.type,
          points: curve.points
            .slice(firstValidIndex, lastValidIndex + 1)
            .map(function (point) {
              return {
                x: point.x - startTime,
                y: point.y,
              };
            }),
        }
        : curve.type == "BEZIER"
          ? {
            type: curve.type,
            points: curve.points
              .slice(firstValidIndex, lastValidIndex + 1)
              .map(function (point) {
                return {
                  x: point.x - startTime,
                  y: point.y,
                  lx: point.lx - startTime,
                  ly: point.ly,
                  rx: point.rx - startTime,
                  ry: point.ry,
                  constSeg: point.constSeg,
                };
              }),
          }
          : {
            type: curve.type,
            points: curve.points
              .slice(firstValidIndex, lastValidIndex + 1)
              .map(function (point) {
                return {
                  lockedInTime: point.lockedInTime - startTime,
                  x: point.x,
                  y: point.y,
                  z: point.z,
                  tension: point.tension,
                  continuity: point.continuity,
                  bias: point.bias,
                };
              }),
          };
}

/**
 * Given a bezier column, get the value at every frame
 * @param {string} columnName
 */
exports.precalculateBezier = function (columnName) {
  var result = [];
  for (var timelineFrame = 0; timelineFrame < frame.numberOf(); timelineFrame++)
  {
    var numberOrNan = parseFloat(column.getEntry(columnName, 0, timelineFrame + 1));
    result.push(isNaN(numberOrNan) ? 0 : numberOrNan);
  }
  return result;
}

/**
 * @param {string} columnName
 * @param {{ precalculateBezier?: boolean}} settings
 * @returns {Curve & { type: "BEZIER" } | Stream}
 */
exports.parseBezierForPoints = function (columnName, settings) {

  if (settings.precalculateBezier)
  {
    return { type: "STREAM", valueAtIndex: exports.precalculateBezier(columnName) };
  }
  var result = [];
  var pointsLength = func.numberOfPoints(columnName);
  for (var i = 0; i < pointsLength; i++)
  {
    result.push({
      x: func.pointX(columnName, i),
      y: func.pointY(columnName, i),
      lx: func.pointHandleLeftX(columnName, i),
      ly: func.pointHandleLeftY(columnName, i),
      rx: func.pointHandleRightX(columnName, i),
      ry: func.pointHandleRightY(columnName, i),
      constSeg: func.pointConstSeg(columnName, i),
    });
  }
  return { type: "BEZIER", points: result };
}

var cardinalDirectionToSign = {
  "N": 1,
  "E": 1,
  "S": -1,
  "W": -1,
  "F": 1,
  "B": -1,
}

/**
 * @param {string} columnName
 * @param {{ precalculateBezier?: boolean}} settings
 * @returns {Array<Curve & { type: "BEZIER"} | Stream>}
 */
exports.parse3DPathForPoints = function (columnName, settings) {
  return [1, 2, 3].map(function (subcolumn, index) {
    var result = [];
    for (var timelineFrame = 0; timelineFrame < frame.numberOf(); timelineFrame++)
    {
      var cardinalvalue = /**@type [string, "N" | "E" | "S" | "W" | "F" | "B"]*/(
        column.getEntry(columnName, subcolumn, timelineFrame + 1).split(" ")
      );
      var numberOrNan = parseFloat(cardinalvalue[0]);
      var sign = cardinalvalue[1] == null ? 1 : cardinalDirectionToSign[cardinalvalue[1]];
      result.push(isNaN(numberOrNan) ? 0 : numberOrNan * sign);
    }
    return { type: "STREAM", valueAtIndex: result };
  });
}

/**
 * @param {string} columnName
 * @returns {Stream}
 */
exports.parseDrawingForValues = function (columnName) {
  // Collect all possible values of drawing, into a single lookup from string to number.
  var drawingToIndex = /**@type Record<string, number | null>*/({});
  var newIndex = 0;
  for (var timelineFrame = 1; timelineFrame <= frame.numberOf(); timelineFrame++)
  {
    var nameOrExposure = column.getEntry(columnName, 1, timelineFrame);
    if (drawingToIndex[nameOrExposure] == null)
    {
      drawingToIndex[nameOrExposure] = newIndex++;
    }
  }
  // Run through timeline and compose array of values.
  var result = [];
  for (var timelineFrame = 1; timelineFrame <= frame.numberOf(); timelineFrame++)
  {
    var nameOrExposure = column.getEntry(columnName, 1, timelineFrame);
    var index = drawingToIndex[nameOrExposure];
    result.push(/**@type number*/(index));
  }
  return {
    type: "STREAM",
    valueAtIndex: result,
  };
}

/**
 * @template T
 * @param {{
 *  skinName: SkinName,
 *  nodePaths: NodePath[],
 *  timelineFrame: number,
 *  spriteIdxLookup: Record<NodePath, Lookup<SkinName, (number | null)[]>>,
 *  preRegisterUndo: boolean,
 * }} props 
 * @param { () => T } process
 * @retuns T
 */
exports.withTempSkinSwappedDrawingsAtFrame = function (props, process) {
  var undoChangeRegistered = props.preRegisterUndo;
  try
  {
    scene.beginUndoRedoAccum(translator.tr("Render Node"));

    props.nodePaths.forEach(function (nodePath) {
      var spriteIdxLookupAtPath = props.spriteIdxLookup[nodePath];
      var timelineToSpriteIdx = spriteIdxLookupAtPath[props.skinName];
      if (timelineToSpriteIdx == null) return;
      var newSpriteIdx = timelineToSpriteIdx[props.timelineFrame - 1];
      var columnName = node.linkedColumn(nodePath, "DRAWING.ELEMENT");
      var elementId = column.getElementIdOfDrawing(columnName);
      var newSprite = newSpriteIdx == null ? "" : Drawing.name(elementId, newSpriteIdx);
      var currentSprite = column.getEntry(columnName, 1, props.timelineFrame);
      if (currentSprite != newSprite)
      {
        column.setEntry(columnName, 1, props.timelineFrame, newSprite);
        undoChangeRegistered = true;
      }
    });

    return process();
  }
  finally
  {
    scene.endUndoRedoAccum();
    if (undoChangeRegistered)
    {
      scene.undo();
      if ("clearRedo" in scene)
        scene.clearRedo();
    }
  }
}
