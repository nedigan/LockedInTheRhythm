/* find 7zip binary - used to zip template */
exports.find7Zip = function () {
  var p;
  if (about.isMacArch() || about.isLinuxArch()) {
    p = specialFolders.bin + "/../../external/macosx/p7zip/7za";
    if (new File(p).exists) {
      return p;
    }
    p = specialFolders.bin + "/bin_3rdParty/7za";
    if (new File(p).exists) {
      return p;
    }
  }
  else if (about.isWindowsArch()) {
    p = specialFolders.bin + "/bin_3rdParty/7z.exe";
    if (new File(p).exists) {
      return p;
    }
  }
  MessageBox.critical("Cannot find 7zip to save out .tbg file. Aborting");
  throw new Error("cannot find 7zip");
}

/**
 * @param {string} path 
 * @returns {string}
 */
exports.escapeSpaces = function (path) {
  if (about.isWindowsArch()) {
    var v = "\"\"" + path + "\"\""
    return v;
  }
  return path;
}

/**
 * @param {string} inputFolder
 * @param {string} outputFile
 */
exports.saveFolderToArchive = function (inputFolder, outputFile) {
  var zipPath = exports.find7Zip();
  var process = new Process2(zipPath, "a", "-tzip", "-mx0", exports.escapeSpaces(outputFile), exports.escapeSpaces(inputFolder + "/*"));
  var processResult = process.launch();
  MessageLog.trace("Running command: " + process.commandLine())
  if (processResult != 0) {
    MessageLog.trace(process.errorCode())
    throw new Error("Archive process of file " + outputFile + " could not be completed.");
  }
  MessageLog.trace("File created: " + outputFile);
  return true;
}