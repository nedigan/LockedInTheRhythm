/*
 * Copyright Toon Boom Animation Inc - 2022
 */

/**
 * @param {boolean} [hideProgress]
 * @param {QWidget} [parent]
 */
exports.ProgressBar = function (hideProgress, parent) {
  var progressDialog = new QProgressDialog(parent);
  var performanceStats = /**@type Array<{ process: string, category: string, startTime: number, messages: Array<{ message: string, startTime: number }> }>*/([]);
  var _canceled = false;

  this.wasCanceled = function () {
    return _canceled;
  }

  /**
   * @param {{
   *  title: string
   *  items: number
   * }} props
   */
  this.Process = function (props) {

    if (!hideProgress)
    {
      progressDialog.autoClose = true;
      progressDialog.modal = true;
      progressDialog.show();
      progressDialog.setRange(0, props.items + 1);
      progressDialog.setValue(0);
    }

    var localProgressCounter = 1;

    /**
     * @param {string} category
     * @param {string} [message]
     */
    this.tryIncrementCancellable = function (category, message) {

      var latestCategory = category.split("...").join("");

      var latestStats = performanceStats[performanceStats.length - 1];
      if (latestStats == null
        || latestStats.category != latestCategory)
      {
        latestStats = {
          process: props.title,
          category: latestCategory,
          startTime: Date.now(),
          messages: [],
        };
        performanceStats.push(latestStats);
      }
      var latestMessage = latestStats.messages[latestStats.messages.length - 1];
      if (message != null
        && (latestMessage == null
          || latestMessage.message != message))
      {
        latestStats.messages.push({ message: message, startTime: Date.now() });
      }

      if (hideProgress)
        return;
      if (progressDialog.wasCanceled)
      {
        _canceled = true;
        throw "Cancelled by user";
      }
      if (localProgressCounter >= props.items)
      {
        props.items = localProgressCounter;
        progressDialog.setRange(0, props.items + 1);
      }
      if (message != null)
        progressDialog.setLabelText(category + " - " + message);
      else
        progressDialog.setLabelText(props.title + " - " + category);
      progressDialog.setValue(localProgressCounter++);
    }
  }

  this.close = function () {
    progressDialog.close();

    if (performanceStats.length > 0)
    {
      var finalStats = performanceStats.map(function (stat, index) {
        var nextTime = index + 1 >= performanceStats.length
          ? Date.now()
          : performanceStats[index + 1].startTime;
        return {
          process: stat.process,
          category: stat.category,
          duration: nextTime - stat.startTime,
          messages: stat.messages
            .map(function (message, messageIdx) {
              var nextMessageTime = messageIdx + 1 >= stat.messages.length
                ? nextTime
                : stat.messages[messageIdx + 1].startTime;
              return {
                message: message.message,
                duration: nextMessageTime - message.startTime,
              };
            })
            .sort(function (a, b) { return b.duration - a.duration }),
        };
      });

      var lastProcess = null;
      var tab = "  ";
      MessageLog.trace("Task complete in " + Math.ceil((Date.now() - performanceStats[0].startTime) / 100) / 10 + " seconds");
      for (var i = 0; i < finalStats.length; i++)
      {
        var stat = finalStats[i];
        if (stat.process != lastProcess)
        {
          lastProcess = stat.process;
          MessageLog.trace(tab + "º " + stat.process);
        }
        MessageLog.trace(tab + tab + "» " + stat.duration + "ms - " + stat.category);
        for (var messageIdx = 0; messageIdx < Math.min(10, stat.messages.length); messageIdx++)
        {
          var message = stat.messages[messageIdx];
          MessageLog.trace(tab + tab + tab + (messageIdx + 1) + ". " + message.message + " (" + message.duration + "ms)");
        }
        if (stat.messages.length > 10)
        {
          MessageLog.trace(tab + tab + tab + "... " + (stat.messages.length - 10) + " more...");
        }
      }
    }
  }
}