/*
 * Copyright Toon Boom Animation Inc - 2022
 */

var XML = require("./TB_XMLBuilder.js");
var ObjUtil = require("./TB_ObjUtil.js");

/**
 * @param {string} path
 * @param {string} string
 */
exports.saveString = function (path, string) {
  var file = new File(path);
  try
  {
    file.open(FileAccess.WriteOnly);
    file.write(string);
    file.close();
  }
  catch (err)
  {
    MessageBox.warning("Unable to save file at " + path + " --- " + err, MessageBox.Ok, MessageBox.NoButton);
  }

  // MessageLog.trace("Saved file at " + path);
}

/**
 * @param {string} path
 * @param {string} string
 */
exports.appendString = function (path, string) {
  var file = new File(path);
  try
  {
    file.open(FileAccess.Append);
    file.write(string);
    file.close();
  }
  catch (err)
  {
    MessageBox.warning("Unable to save file at " + path + " --- " + err, MessageBox.Ok, MessageBox.NoButton);
  }
}

/**
 * Reads an existing XML file in, merges new children in with old children
 * from first existing XML tag, matching on a child attribute.
 * Contents is saved back to original file.
 * @template {Array<XML.Blueprint>} T
 * @param {string} filePath
 * @param {{
 *   tag: string,
 *   attributes?: any,
 *   overwrite: boolean,
 *   mergeChildAttribute: keyof T[number]["attributes"], 
 *   children: T
 * }} props
 */
exports.mergeXMLFile = function (filePath, props) {
  var previousFile = props.overwrite ? null : exports.readString(filePath, { showError: false });
  var previousChildren = previousFile == null ? null : XML.Blueprint.fromXMLString(previousFile).children;
  var newElementAttrLookup = ObjUtil.fromEntries(props.children
    .map(function (elem) { return { key: elem.attributes[props.mergeChildAttribute], value: true } }));
  exports.saveString(filePath, new XML.Builder({
    tag: props.tag,
    attributes: props.attributes,
    children: (previousChildren == null ? [] : previousChildren)
      .filter(function (child) { return !newElementAttrLookup[child.attributes[props.mergeChildAttribute]]; })
      .concat(props.children)
  }).toXMLString());
}

/**
 * @param {string} path
 * @param {{ showError: boolean }} [settings]
 */
exports.readString = function (path, settings) {
  var file = new File(path);

  try
  {
    file.open(1 /* FileAccess.ReadOnly */);
    var string = file.read();
    file.close();

    // MessageLog.trace("Read file at " + path);
    return string;
  }
  catch (err)
  {
    if (settings == null || settings.showError)
    {
      MessageBox.warning("Unable to read file at " + path + " --- " + err, MessageBox.Ok, MessageBox.NoButton);
    }
  }
}

/**
 * @param {string} existingRoot
 * @param {string[]} folderStructure
 */
exports.ensureFolderStructureExists = function (existingRoot, folderStructure) {
  var existingFolder = existingRoot;
  for (var i = 0; i < folderStructure.length; i++)
  {
    var currentFolder = folderStructure[i];
    var dir = new QDir(existingFolder);
    dir.mkdir(currentFolder);
    existingFolder += "/" + currentFolder;
  }
  return existingFolder;
}

/**
 * Removes folder, all contents and any Unity-specific .meta files associated with this folder
 * @param {string} path
 */
exports.removeFolder = function (path) {
  var fileinfo = new QFileInfo(path);
  if (fileinfo.exists() && fileinfo.isDir())
  {
    var dir = new Dir;
    dir.path = path;
    dir.rmdirs();
  }
  new QFile(path + ".meta").remove();
}

exports.currentProjectPath = function () {
  if ("currentContainerPath" in scene)
  {
    var path = scene.currentContainerPath();
    var info = new QFileInfo(path);
    if (info.isFile())  // must be an archive *.tgs
      return info.absolutePath().replace("\\", "/");

    var dir = new QDir(scene.currentProjectPathRemapped());
    return dir.absolutePath().replace("\\", "/");
  }
  else
  {
    return scene.currentProjectPathRemapped();
  }
}

/**
 * Returns parent folder or empty string
 * @param {string} path
 */
exports.parentFolder = function (path) {
  var index = Math.max(path.lastIndexOf("/"), path.lastIndexOf("\\"));
  if (index < 0)
    return "";
  return path.substring(0, index);
}

/**
 * Returns true if file exists
 * @param {string} path
 */
exports.fileExists = function (path) {
  var fileinfo = new QFileInfo(path);
  return fileinfo.exists() && !fileinfo.isDir();
}

/**
 * Returns true if folder exists
 * @param {string} path
 */
exports.folderExists = function (path) {
  var fileinfo = new QFileInfo(path);
  return fileinfo.exists() && fileinfo.isDir();
}

exports.currentScenePath = function () {
  if ("currentContainerPath" in scene)
  {
    var path = scene.currentContainerPath();
    var info = new QFileInfo(path);
    if (info.isFile())  // eg an archive *.tgs
      return path;

    return path + "/" + scene.currentVersionName() + ".xstage";
  }
  else
  {
    return scene.currentScene();
  }
}

exports.getTgsPath = function(){
  // Search for the first "Assets" folder that is a child of a parent folder.
  var dir = exports.currentProjectPath();
  for (var _path = dir; _path != ""; _path = exports.parentFolder(_path))
  {
    var path = _path + "/Assets";
    if (exports.folderExists(path))
    {
      dir = path
      break
    }
  }

  // Get the relative path to the scene from that "Assets" folder.
  var filepath = exports.currentScenePath();
  return new QDir(dir).relativeFilePath(filepath);
}